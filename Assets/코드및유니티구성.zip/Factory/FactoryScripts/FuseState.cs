using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FuseState : MonoBehaviour
{
    public bool FuseUse = false;
    public void FuseOn()
    {
        FuseUse = true;
    }
}
